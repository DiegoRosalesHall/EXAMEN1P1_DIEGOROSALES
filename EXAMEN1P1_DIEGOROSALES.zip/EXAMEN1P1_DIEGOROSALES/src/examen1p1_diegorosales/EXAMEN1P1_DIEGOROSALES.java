package examen1p1_diegorosales;
import java.util.Scanner;
import java.util.Random;
public class EXAMEN1P1_DIEGOROSALES {
    static Scanner mcgregor= new Scanner(System.in);
    static void trifuerza(){
        System.out.println("Introduzca el tamaño: ");
        int tamaño = mcgregor.nextInt();
        int contador_i = 1;
        int contador_j = 0;
        if(tamaño%2==0 && (tamaño/2)%2!=0){
            
            for(int i=1;i<=(tamaño/2)+1;i++){
                
                for(int j = 1;j<=tamaño+1;j++){
                    contador_j+=1;
                    if(j==(tamaño/2)+1 && contador_i==1){
                    System.out.print("* ");
                    }
                    
                    if(j==16 || j==15 ||j==14){
                        if(contador_i==2){
                            System.out.print("* ");
                        }
                    }
                    
                    
                    else {
                        System.out.print("_  ");
                        
                   
                    }
            
                }// J
                contador_j=0;
        System.out.println();
        contador_i+=1;
            }// I
        }
        else{
            System.out.println("El numero ingresado es impar, su mitad es impar, o es menor a 20");
            
        }
    }
    
    
    
    
    public static void main(String[] args) {
       Random rand = new Random();

        
        
        
        
        while(true){ //while menu
            System.out.println("~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~");
            System.out.println("    Bienvenido al menu, escoga su programa. ");
            System.out.println("    1.~ Fight or Flight ");
            System.out.println("    2.~ Tri fuerza(HACER VOID PARA ESTE) ");
            int opcion_menu = mcgregor.nextInt();
            switch(opcion_menu){
                case 1:
                    
                    
                    
                    System.out.println("Ingrese maestria: ");
                    System.out.println("1.~ Principiante (0% de hit extra + extra damage) ");
                    System.out.println("2.~ Intermedio (5% de hit extra + extra damage) ");
                    System.out.println("3.~ Experto (10% de hit extra + extra damage) ");
                    int maestria = mcgregor.nextInt();
                    int balas = 25;
                    int vida_zombie = 25;
                    int distancia_zombie = rand.nextInt(15,30);
                    int distancia_recorrida;
                    int daño=1;
                    int probabilidad_hit;
                    String respuesta ="S";
                    char S = respuesta.charAt(0);
                    String respuesta_usuario;
                    String RESPUESTA_USUARIO;
                    char decision_usuario;
                    
                   
                    
                    
                    
                    
                    if( maestria == 1 ){
                        System.out.println("EL ZOMBIE SE ENCUENTRA A: "+distancia_zombie+" METROS!");
                        System.out.println("");   
                        System.out.println("EL JUGADOR CUENTA CON: "+balas+" BALAS!");
                        System.out.println("");
                        
                        while( vida_zombie != 0 || distancia_zombie != 0){
                            probabilidad_hit = rand.nextInt(1,100);
                            if(probabilidad_hit<=65){
                                daño=rand.nextInt(1,7);
                                System.out.println("HIT! El tiro ha reducido el HP del zombie un total de: "+daño);
                                balas-=1;
                                System.out.println("Quedan: "+balas+" balas");
                                vida_zombie-=daño;
                                if(vida_zombie<=0){
                                    vida_zombie=0;
                                }
                                
                            
                                System.out.println("Vida restante del zombie: "+vida_zombie);
                                System.out.println("El zombie se encuentra a: "+distancia_zombie);
                                if(vida_zombie==0){
                                   System.out.println("~~~ VICTORIA ~~~");
                                    System.out.println(" ¡HAS ASESINADO AL ZOMBIE!"); 
                                    break;
                                }
                                
                                
                                if(balas==0){
                                    System.out.println("~~~ GAME OVER ~~~");
                                    System.out.println(" ¡Te quedaste sin balas! ");
                                    break;
                                }
                                
                                System.out.println("Listo para la siguiente ronda? [ S / N ]");
                                
                                respuesta_usuario = mcgregor.next();
                                 RESPUESTA_USUARIO = respuesta_usuario.toUpperCase();
                                decision_usuario = RESPUESTA_USUARIO.charAt(0);
                                
                                
                                if(decision_usuario!=S){
                                    System.out.println("FIN DEL JUEGO");
                                    System.out.println("");
                                    break;
                                    
                                }
                            }
                        
                        
                               
                                
                                
                                
                            
                            
                        
                        
                            else {
                                distancia_recorrida = rand.nextInt(3,5);
                                distancia_zombie -= distancia_recorrida;
                                if(distancia_zombie<0){
                                distancia_zombie=0;
                                     }
                                
                                balas-=1;
                                
                                System.out.println("Ha fallado! El zombie se encuentra a: "+distancia_zombie+" Metros");
                                 System.out.println("Vida restante del zombie: "+vida_zombie);
                                System.out.println("Quedan: "+balas+" balas");
                                if( distancia_zombie==0){
                                    System.out.println("~~~ GAME OVER ~~~");
                                    System.out.println(" ¡El zombie te ha alcanzado!");
                                    break;
                                }
                                if(balas==0){
                                    System.out.println("~~~ GAME OVER ~~~");
                                    System.out.println(" ¡Te quedaste sin balas! ");
                                    break;
                                }
                                System.out.println("Listo para la siguiente ronda? [ S / N ]");
                                
                                respuesta_usuario = mcgregor.next();
                                RESPUESTA_USUARIO = respuesta_usuario.toUpperCase();
                                decision_usuario = RESPUESTA_USUARIO.charAt(0);
                                
                                
                                
                                if(decision_usuario!=S){
                                    System.out.println("FIN DEL JUEGO");
                                    System.out.println("");
                                    break;
                                    
                                }
                                          
                                    
                            }
                        }// FIN WHILE PRINCIPIANTE
                    } // principiante
                    
            
                            
                            
                            
                            
                            
                        
                        //PRINCIPIANTE
                        
                    
                    
                    
                    
                    
                    
                    
                    
                    
                    
                    
                    
                    
                    
                    
                    else if (maestria==2){
                        System.out.println("EL ZOMBIE SE ENCUENTRA A: "+distancia_zombie+" METROS!");
                        System.out.println("");   
                        System.out.println("EL JUGADOR CUENTA CON: "+balas+ " BALAS!");
                        System.out.println("");
                        while( vida_zombie != 0 || distancia_zombie != 0){
                            probabilidad_hit = rand.nextInt(1,100);
                            if(probabilidad_hit<=70){
                                daño=rand.nextInt(1,7);
                                System.out.println("HIT! El tiro ha reducido el HP del zombie un total de: "+daño);
                                balas-=1;
                                System.out.println("Quedan: "+balas+" balas");
                                vida_zombie-=daño;
                                if(vida_zombie<=0){
                                    vida_zombie=0;
                                }
                                
                            
                                System.out.println("Vida restante del zombie: "+vida_zombie);
                                System.out.println("El zombie se encuentra a: "+distancia_zombie);
                                if(vida_zombie==0){
                                   System.out.println("~~~ VICTORIA ~~~");
                                    System.out.println(" ¡HAS ASESINADO AL ZOMBIE!"); 
                                    break;
                                }
                                
                                
                                if(balas==0){
                                    System.out.println("~~~ GAME OVER ~~~");
                                    System.out.println(" ¡Te quedaste sin balas! ");
                                    break;
                                }
                                
                                System.out.println("Listo para la siguiente ronda? [ S / N ]");
                                
                                respuesta_usuario = mcgregor.next();
                                 RESPUESTA_USUARIO = respuesta_usuario.toUpperCase();
                                decision_usuario = RESPUESTA_USUARIO.charAt(0);
                                
                                
                                if(decision_usuario!=S){
                                    System.out.println("FIN DEL JUEGO");
                                    System.out.println("");
                                    break;
                                    
                                }
                            }
                        
                        
                               
                                
                                
                                
                            
                            
                        
                        
                            else {
                                distancia_recorrida = rand.nextInt(3,5);
                                distancia_zombie -= distancia_recorrida;
                                if(distancia_zombie<0){
                                distancia_zombie=0;
                                     }
                                
                                balas-=1;
                                
                                System.out.println("Ha fallado! El zombie se encuentra a: "+distancia_zombie+" Metros");
                                 System.out.println("Vida restante del zombie: "+vida_zombie);
                                System.out.println("Quedan: "+balas+" balas");
                                if( distancia_zombie==0){
                                    System.out.println("~~~ GAME OVER ~~~");
                                    System.out.println(" ¡El zombie te ha alcanzado!");
                                    break;
                                }
                                if(balas==0){
                                    System.out.println("~~~ GAME OVER ~~~");
                                    System.out.println(" ¡Te quedaste sin balas! ");
                                    break;
                                }
                                System.out.println("Listo para la siguiente ronda? [ S / N ]");
                                
                                respuesta_usuario = mcgregor.next();
                                RESPUESTA_USUARIO = respuesta_usuario.toUpperCase();
                                decision_usuario = RESPUESTA_USUARIO.charAt(0);
                                
                                
                                
                                if(decision_usuario!=S){
                                    System.out.println("FIN DEL JUEGO");
                                    System.out.println("");
                                    break;
                                    
                                }
                                          
                                    
                            }
                        }
                        
                        
                        
                    }//INTERMEDIO
                            
                            
                    else if( maestria==3){
                        System.out.println("EL ZOMBIE SE ENCUENTRA A: "+distancia_zombie+" METROS!");
                        System.out.println("");   
                        System.out.println("EL JUGADOR CUENTA CON: "+balas+" BALAS!");
                        System.out.println("");
                        while( vida_zombie != 0 || distancia_zombie != 0){
                            probabilidad_hit = rand.nextInt(1,100);
                            if(probabilidad_hit<=80){
                                daño=rand.nextInt(1,7);
                                System.out.println("HIT! El tiro ha reducido el HP del zombie un total de: "+daño);
                                balas-=1;
                                System.out.println("Quedan: "+balas+" balas");
                                vida_zombie-=daño;
                                if(vida_zombie<=0){
                                    vida_zombie=0;
                                }
                                
                            
                                System.out.println("Vida restante del zombie: "+vida_zombie);
                                System.out.println("El zombie se encuentra a: "+distancia_zombie);
                                if(vida_zombie==0){
                                   System.out.println("~~~ VICTORIA ~~~");
                                    System.out.println(" ¡HAS ASESINADO AL ZOMBIE!"); 
                                    break;
                                }
                                
                                
                                if(balas==0){
                                    System.out.println("~~~ GAME OVER ~~~");
                                    System.out.println(" ¡Te quedaste sin balas! ");
                                    break;
                                }
                                
                                System.out.println("Listo para la siguiente ronda? [ S / N ]");
                                
                                respuesta_usuario = mcgregor.next();
                                 RESPUESTA_USUARIO = respuesta_usuario.toUpperCase();
                                decision_usuario = RESPUESTA_USUARIO.charAt(0);
                                
                                
                                if(decision_usuario!=S){
                                    System.out.println("FIN DEL JUEGO");
                                    System.out.println("");
                                    break;
                                    
                                }
                            }
                        
                        
                               
                                
                                
                                
                            
                            
                        
                        
                            else {
                                distancia_recorrida = rand.nextInt(3,5);
                                distancia_zombie -= distancia_recorrida;
                                if(distancia_zombie<0){
                                distancia_zombie=0;
                                     }
                                
                                balas-=1;
                                
                                System.out.println("Ha fallado! El zombie se encuentra a: "+distancia_zombie+" Metros");
                                 System.out.println("Vida restante del zombie: "+vida_zombie);
                                System.out.println("Quedan: "+balas+" balas");
                                if( distancia_zombie==0){
                                    System.out.println("~~~ GAME OVER ~~~");
                                    System.out.println(" ¡El zombie te ha alcanzado!");
                                    break;
                                }
                                if(balas==0){
                                    System.out.println("~~~ GAME OVER ~~~");
                                    System.out.println(" ¡Te quedaste sin balas! ");
                                    break;
                                }
                                System.out.println("Listo para la siguiente ronda? [ S / N ]");
                                
                                respuesta_usuario = mcgregor.next();
                                RESPUESTA_USUARIO = respuesta_usuario.toUpperCase();
                                decision_usuario = RESPUESTA_USUARIO.charAt(0);
                                
                                
                                
                                if(decision_usuario!=S){
                                    System.out.println("FIN DEL JUEGO");
                                    System.out.println("");
                                    break;
                                    
                                }
                                          
                                    
                            }
                        }
                        
                        
                    }// EXPERTO
                    
                    
                   
                    break; 
                        //FIN DEL CASE 1
                    
                case 2:
                    trifuerza();
                    
                    
                    
                    
                    // hacer void de la trifuerza
                    break; //FIN DEL CASE 2
            
            
            }// fin de switch menu
                    }// fin del while del menu
            }// FIN DEL MAIN    
            }// FIN DE CLASS
    
  
                
                
                
    
    

